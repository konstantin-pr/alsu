<?php
if ( ! defined( 'WPINC' ) ) {
	die ;
}

?>

<span class="litespeed-desc">
	<?php echo __( 'This will communicate with LiteSpeed\'s Image Optimization Server and retrieve the most recent status.', 'litespeed-cache' ) ; ?>
</span>
