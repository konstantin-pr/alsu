<?php
/**
* Plugin Name: Eventchamp Elements
* Plugin URI: http://themeforest.net/user/gloriathemes
* Description: Elements of Eventchamp theme is exist in the plugin.
* Version: 1.5.1
* Author: Gloria Themes
* Author URI: http://gloriathemes.com/
*/

	require_once ( dirname( __FILE__ ) . '/core.php');
	require_once ( dirname( __FILE__ ) . '/post-types.php');
	require_once ( dirname( __FILE__ ) . '/page-builder-elements.php');