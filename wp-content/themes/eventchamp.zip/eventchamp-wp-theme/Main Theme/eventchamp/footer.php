
	<?php eventchamp_footer(); ?>
	<?php eventchamp_content_after(); ?>
	<?php eventchamp_wrapper_after(); ?>
	<?php wp_footer(); ?>
	</body>
</html>